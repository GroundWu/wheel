#include "func.h"

int main()
{
	 init();
	 run();
	
}

